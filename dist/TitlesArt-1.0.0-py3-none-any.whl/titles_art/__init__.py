from .main import text_to_col, print_text
from .abecedario_ascii import *